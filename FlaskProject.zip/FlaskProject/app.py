from flask import Flask, render_template, url_for, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
db = SQLAlchemy(app)


#creating model
class Todo(db.Model):  #  in django we write like this models.Model
    id = db.Column(db.Integer, primary_key=True)  # id = models.charfield(max)
    content = db.Column(db.String(200), nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)  # date_created = models.DateTimeField(auto_now_add=True)

    def __str__(self):     
        return '<Task %r>' % self.id



@app.route('/', methods=['POST', 'GET'])
def index():
    if request.method == 'POST':
        task_content = request.form['content']
        new_task = Todo(content=task_content)  # create model(To-do)object  # 

        try:
            db.session.add(new_task)  # here we add new_task to database
            db.session.commit() # commit
            return redirect('/')
        except:
            return 'There was an issue adding your task'

    else: 
        tasks = Todo.query.order_by(Todo.date_created).all()  # first  # Todo.object.all().order_by('date_created')
        return render_template('index.html', tasks=tasks) # context tasks.. {'task':}


@app.route('/delete/<int:id>')
def delete(id):
    task_to_delete = Todo.query.get_or_404(id)

    try:
        db.session.delete(task_to_delete)
        db.session.commit()
        return redirect('/')
    except:
        return 'There was a problem deleting that task'

@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update(id):
    task = Todo.query.get_or_404(id)

    if request.method == 'POST':
        task.content = request.form['content']

        try:
            db.session.commit()
            return redirect('/')
        except:
            return 'There was an issue updating your task'

    else:
        return render_template('update.html', task=task)



"""
show some message like "hello world!
@app.route('/')
def index():
    return "hello world"


"""

if __name__ == "__main__":
    app.run(debug=True)
